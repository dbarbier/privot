"computeTestTwoSampleSmirnov" <-
function(numericalSample1, numericalSample2, testLevel = 0.95) {

  # Direct application of ks.test ('stats' package).
  testKs <- ks.test(numericalSample1, numericalSample2)

  pValue <- testKs$p.value

  testResult <- ifelse(pValue > 1 - testLevel, 1, 0)
  return(list(test = "TwoSampleSmirnov",
              testResult = testResult,
              threshold = 1 - testLevel,
              pValue = pValue))
}

