"computeTruncatedNormalPdf" <-
function(point, mu, sigma, a, b) {
  # Call to the relevant function, taken from the msm package by C. H. Jackson, available on CRAN.
  dtnorm(point, mu, sigma, a, b)
}

